const todos = require('./todos');
const todoItems = require('./todoItems');

module.exports = {
  todos,
  todoItems,
};